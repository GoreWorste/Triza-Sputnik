<?php
/**
 * hotVacancies — up to 4 "hot" vacancy RESOURCES (TV vac_homepage=1, published)
 * for the bottom block. Newest first (by original id in alias).
 */
$prefix = $modx->getOption('table_prefix');
$sc  = $prefix . 'site_content';
$cvt = $prefix . 'site_tmplvar_contentvalues';
$tvt = $prefix . 'site_tmplvars';
$esc = function ($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); };

$container = $modx->findResource('vacancy');

// ids of published vacancies with vac_homepage = 1
$sql = "SELECT c.id, c.pagetitle, c.alias
        FROM {$sc} c
        JOIN {$cvt} cv ON cv.contentid = c.id
        JOIN {$tvt} tv ON tv.id = cv.tmplvarid AND tv.name = 'vac_homepage'
        WHERE c.parent = " . (int)$container . " AND c.published = 1 AND c.deleted = 0
          AND c.isfolder = 0 AND cv.value = '1'
        ORDER BY IF(c.alias REGEXP '^[0-9]+$', CAST(c.alias AS UNSIGNED), c.id) DESC
        LIMIT 4";
$stmt = $modx->query($sql);
$rows = $stmt ? $stmt->fetchAll(PDO::FETCH_ASSOC) : array();

// bulk fetch needed TVs for these
$ids = array();
foreach ($rows as $r) $ids[] = (int)$r['id'];
$tvmap = array();
if ($ids) {
    $in = implode(',', $ids);
    $ts = $modx->query("SELECT cv.contentid, tv.name, cv.value FROM {$cvt} cv
        JOIN {$tvt} tv ON tv.id = cv.tmplvarid
        WHERE cv.contentid IN ({$in}) AND tv.name IN ('vac_city','vac_contract','vac_salary')");
    if ($ts) foreach ($ts->fetchAll(PDO::FETCH_ASSOC) as $t) { $tvmap[$t['contentid']][$t['name']] = $t['value']; }
}
$labels = array('0'=>'Полный рабочий день','1'=>'Временный сотрудник','2'=>'Сменный график','3'=>'Вахта');

$out = '<ul class="jobokay_latest_responsive" style="list-style-type: none;">' . "\n";
foreach ($rows as $r) {
    $id = (int)$r['id'];
    $tv = isset($tvmap[$id]) ? $tvmap[$id] : array();
    $title = $esc($r['pagetitle']);
    $loc = $esc(isset($tv['vac_city']) ? $tv['vac_city'] : '');
    $contract = isset($tv['vac_contract']) ? (string)$tv['vac_contract'] : '0';
    $cl = $esc(isset($labels[$contract]) ? $labels[$contract] : $contract);
    $salary = isset($tv['vac_salary']) ? $tv['vac_salary'] : '';
    $link = '/vacancy/' . rawurlencode($r['alias']);
    $out .= '<li class="joboffer col-sm-3"><h4><a class="jobtitle" href="' . $link . '">' . $title . '</a></h4>' . "\n";
    $out .= '      <div class="jobokay_latest_header">' . $cl . ' в город ' . $loc . '</div>' . "\n";
    $out .= '      <div class="jobokay_latest_details">' . $salary . "\n      </div>\n";
    $out .= '      <div class="jobokay_latest_footer">' . "\n";
    $out .= '      <div class="jobokay_latest_specifics"></div>' . "\n";
    $out .= '      <div class="jobokay_latest_readmore"><a class="readmore" href="' . $link . '">Посмотреть</a></div>' . "\n";
    $out .= "      </div>\n      </li>";
}
$out .= '<li>' . "\n  " . '<a href="/vacancy">Посмотреть все вакансии  </a>' . "\n</li>\n</ul>";
return $out;
