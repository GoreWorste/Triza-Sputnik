<?php
/**
 * spMenu — renders the main megamenu 1:1 with active-state detection.
 */
$uri = '';
if ($modx->resource) {
    $uri = (string)$modx->resource->get('uri');
}
$uri = ltrim($uri, '/');

// determine active top-level section
$active = 'home';
if (strpos($uri, 'about') === 0) $active = 'about';
elseif (strpos($uri, 'vacancy') === 0) $active = 'vacancy';
elseif (strpos($uri, 'contacts') === 0) $active = 'contacts';
elseif (strpos($uri, 'blog') === 0) $active = 'blog';
elseif (strpos($uri, 'trainings-and-webinars') === 0) $active = 'trainings';

function ci($section, $active) {
    return $section === $active ? ' current-item active' : '';
}

$tr = ''
 . '<li class="sp-menu-item"><a  href="/trainings-and-webinars/podbor-personala-v-moskvepodbor-personala-v-moskve-treningi-i-vebinaryi"  ><i class="fa fa-arrow-circle-o-right"></i> Подбор персонала в Москве: тренинги и вебинары</a></li>'
 . '<li class="sp-menu-item"><a  href="/trainings-and-webinars/programma-avtorskogo-modulnogo-treninga-olgi-shevelevoj"  ><i class="fa fa-arrow-circle-o-right"></i> Программа авторского модульного тренинга Ольги Шевелевой</a></li>'
 . '<li class="sp-menu-item"><a  href="/trainings-and-webinars/seminaryi-i-treningovyie-programmyi-dlya-biznesa"  ><i class="fa fa-arrow-circle-o-right"></i> Семинары и тренинговые программы для бизнеса</a></li>'
 . '<li class="sp-menu-item"><a  href="/trainings-and-webinars/treningi"  ><i class="fa fa-arrow-circle-o-right"></i> Тренинги</a></li>'
 . '<li class="sp-menu-item"><a  href="/trainings-and-webinars/meropriyatiya-po-tekhnicheskomu-auditu"  ><i class="fa fa-arrow-circle-o-right"></i> Мероприятия по Техническому Аудиту</a></li>';

$out  = '<ul class="sp-megamenu-parent menu-fade hidden-sm hidden-xs">';
$out .= '<li class="sp-menu-item sp-has-child'.ci('home',$active).'"><a  href="/"  >Главная</a>'
      . '<div class="sp-dropdown sp-dropdown-main sp-menu-right" style="width: 300px;"><div class="sp-dropdown-inner"><ul class="sp-dropdown-items">'
      . '<li class="sp-menu-item"><a  href="/home/sertifikat-sto"  >Сертификат СТО</a></li>'
      . '</ul></div></div></li>';
$out .= '<li class="sp-menu-item'.ci('about',$active).'"><a  href="/about"  >О компании</a></li>';
$out .= '<li class="sp-menu-item sp-has-child'.ci('trainings',$active).'"><a  href="javascript:void(0);"  >Тренинги и вебинары</a>'
      . '<div class="sp-dropdown sp-dropdown-main sp-menu-right" style="width: 300px;"><div class="sp-dropdown-inner"><ul class="sp-dropdown-items">'
      . $tr
      . '</ul></div></div></li>';
$out .= '<li class="sp-menu-item'.ci('vacancy',$active).'"><a  href="/vacancy"  >Вакансии</a></li>';
$out .= '<li class="sp-menu-item'.ci('contacts',$active).'"><a  href="/contacts"  >Контакты</a></li>';
$out .= '<li class="sp-menu-item'.ci('blog',$active).'"><a  href="/blog"  >Лента новостей</a></li>';
$out .= '</ul>';

return $out;
