<?php
/**
 * jobList — filtered listing of vacancy RESOURCES (children of the container).
 * Vacancies are MODX resources (template "vacancy") with TVs. Detail pages are
 * rendered by the vacancy template itself, so this snippet is listing-only.
 */
$prefix = $modx->getOption('table_prefix');
$ctbl = $prefix . 'triza_categories';
$esc = function ($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); };

$container = $modx->resource ? (int)$modx->resource->get('id') : 0;

$fCat = isset($_GET['filter_jobcategory']) ? trim($_GET['filter_jobcategory']) : '';
$fLoc = isset($_GET['filter_joblocation']) ? trim($_GET['filter_joblocation']) : '';
$fSearch = isset($_GET['filter_search']) ? trim($_GET['filter_search']) : '';

/* ---- fetch published vacancy children ---- */
$sc = $prefix . 'site_content';
$stmt = $modx->query("SELECT id, pagetitle, alias FROM {$sc}
    WHERE parent = {$container} AND published = 1 AND deleted = 0
      AND class_key = 'modDocument' AND isfolder = 0");
$rows = $stmt ? $stmt->fetchAll(PDO::FETCH_ASSOC) : array();
$byId = array();
$ids = array();
foreach ($rows as $r) { $byId[$r['id']] = $r + array('tv' => array()); $ids[] = (int)$r['id']; }

/* ---- fetch TV values in bulk ---- */
if ($ids) {
    $cvt = $prefix . 'site_tmplvar_contentvalues';
    $tvt = $prefix . 'site_tmplvars';
    $in = implode(',', $ids);
    $ts = $modx->query("SELECT cv.contentid, tv.name, cv.value
        FROM {$cvt} cv JOIN {$tvt} tv ON tv.id = cv.tmplvarid
        WHERE cv.contentid IN ({$in}) AND tv.name LIKE 'vac_%'");
    if ($ts) foreach ($ts->fetchAll(PDO::FETCH_ASSOC) as $t) {
        if (isset($byId[$t['contentid']])) $byId[$t['contentid']]['tv'][$t['name']] = $t['value'];
    }
}

/* ---- category names for search ---- */
$catNames = array();
$cs0 = $modx->query("SELECT id, name FROM {$ctbl}");
if ($cs0) foreach ($cs0->fetchAll(PDO::FETCH_ASSOC) as $c) { $catNames[(string)$c['id']] = $c['name']; }

$labels = array('0'=>'Полный рабочий день','1'=>'Временный сотрудник','2'=>'Сменный график','3'=>'Вахта');

/* ---- filter + collect ---- */
$items = array();
foreach ($byId as $rid => $r) {
    $tv = $r['tv'];
    $cat = isset($tv['vac_category']) ? (string)$tv['vac_category'] : '';
    $city = isset($tv['vac_city']) ? (string)$tv['vac_city'] : '';
    $contract = isset($tv['vac_contract']) ? (string)$tv['vac_contract'] : '0';
    $start = isset($tv['vac_start']) && trim($tv['vac_start']) !== '' ? $tv['vac_start'] : 'Ближайшее время';

    if ($fCat !== '' && $cat !== $fCat) continue;
    if ($fLoc !== '' && $city !== $fLoc) continue;
    if ($fSearch !== '') {
        $hay = $r['pagetitle'] . ' ' . $city . ' ' . (isset($catNames[$cat]) ? $catNames[$cat] : '')
             . ' ' . (isset($tv['vac_salary']) ? $tv['vac_salary'] : '')
             . ' ' . (isset($tv['vac_tasks']) ? $tv['vac_tasks'] : '')
             . ' ' . (isset($tv['vac_profile']) ? $tv['vac_profile'] : '')
             . ' ' . (isset($tv['vac_perspective']) ? $tv['vac_perspective'] : '');
        if (mb_stripos($hay, $fSearch, 0, 'UTF-8') === false) continue;
    }
    $items[] = array(
        'id' => (int)$rid,
        'alias' => $r['alias'],
        'title' => $r['pagetitle'],
        'city' => $city,
        'cl' => isset($labels[$contract]) ? $labels[$contract] : $contract,
        'start' => $start,
    );
}
// sort by original id (alias) desc — newest first, like the original site
usort($items, function ($a, $b) { return ((int)$b['alias']) - ((int)$a['alias']); });

/* ---- category options (published categories) ---- */
$catOpts = '<option value=""> - Все категории - </option>';
$cs = $modx->query("SELECT id, name FROM {$ctbl} WHERE state=1 AND id>1 ORDER BY name ASC");
if ($cs) foreach ($cs->fetchAll(PDO::FETCH_ASSOC) as $c) {
    $sel = ((string)$c['id'] === $fCat) ? ' selected' : '';
    $catOpts .= '<option value="' . (int)$c['id'] . '"' . $sel . '>' . $esc($c['name']) . '</option>';
}
/* ---- location options (distinct among published) ---- */
$locs = array();
foreach ($byId as $r) { $c = isset($r['tv']['vac_city']) ? trim($r['tv']['vac_city']) : ''; if ($c !== '') $locs[$c] = 1; }
$locList = array_keys($locs);
sort($locList, SORT_STRING | SORT_FLAG_CASE);
$locOpts = '<option value=""> - Все города - </option>';
foreach ($locList as $c) {
    $sel = ($c === $fLoc) ? ' selected' : '';
    $locOpts .= '<option value="' . $esc($c) . '"' . $sel . '>' . $esc($c) . '</option>';
}

/* ---- render form ---- */
$form  = '<form action="/vacancy" method="get" name="jobokSearchForm" id="jobokSearchForm">' . "\n";
$form .= '<div id="jobokay_search_container"><div id="filter-bar" class="btn-toolbar">' . "\n";
$form .= '<div class="btn-group pull-left"><select name="filter_jobcategory" class="inputbox" onchange="this.form.submit()">' . $catOpts . '</select></div>' . "\n";
$form .= '<div class="btn-group pull-left"><select name="filter_joblocation" class="inputbox" onchange="this.form.submit()">' . $locOpts . '</select></div>' . "\n";
$form .= '<div class="filter-search btn-group pull-left"><label for="filter_search" class="element-invisible">Поиск...</label>'
       . '<input type="text" name="filter_search" id="filter_search" placeholder="Поиск..." value="' . $esc($fSearch) . '" title="Поиск" /></div>' . "\n";
$form .= '<div class="btn-group pull-left" id="jobsearch_buttons">'
       . '<button class="btn hasTooltip" type="submit" id="jobokay_search_submit" title="Поиск"><i class="icon-search"></i></button>'
       . '<button class="btn hasTooltip" type="button" id="jobokay_search_clear" title="Очистить" onclick="window.location.href=\'/vacancy\'"><i class="icon-remove"></i></button>'
       . '</div>' . "\n";
$form .= '</div></div></form>';

/* ---- render items ---- */
$out = '<div class="items"><div class="items_list">' . "\n";
foreach ($items as $it) {
    $link = '/vacancy/' . rawurlencode($it['alias']);
    $out .= '<div class="itemlayer" id="itemlayer_' . $it['id'] . '" itemtype="http://schema.org/JobPosting" itemscope="">' . "\n";
    $out .= '<div class="itemlist_header" id="itemlist_header_' . $it['id'] . '">' . "\n";
    $out .= '<div class="itemlist_title"><h3>' . $esc($it['title']) . '</h3></div>' . "\n";
    $out .= '<div class="itemlist_textstr">Город: <span itemtype="http://schema.org/Place" itemscope="" itemprop="jobLocation">' . $esc($it['city']) . '</span></div>' . "\n";
    $out .= '<div class="itemlist_textstr">' . $esc($it['cl']) . '</div>' . "\n";
    $out .= '<div class="itemlist_textstr">Дата начала: ' . $esc($it['start']) . ' </div>' . "\n";
    $out .= '<div class="itemlist_textstr" style="clear: right;"></div>' . "\n";
    $out .= '</div><br>' . "\n";
    $out .= '<div class="itemlist_descriptionblock" id="itemlist_descriptionblock_' . $it['id'] . '"><a href="' . $link . '">Посмотреть полное описание вакансии</a><br></div>' . "\n";
    $out .= '</div><hr>' . "\n";
}
$out .= '</div></div>';

return $form . '<br>' . $out;
