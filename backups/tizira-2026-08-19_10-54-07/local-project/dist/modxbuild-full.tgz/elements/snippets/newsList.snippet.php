<?php
/**
 * newsList — "Лента новостей": all news on one page (no pagination).
 */
$parent = isset($parent) ? (int)$parent : ($modx->resource ? (int)$modx->resource->get('id') : 0);

$c = $modx->newQuery('modResource');
$c->where(array('parent' => $parent, 'published' => 1, 'deleted' => 0));
$c->sortby('menuindex', 'ASC');
$c->sortby('id', 'ASC');
$items = $modx->getCollection('modResource', $c);

$esc = function ($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); };

$o  = '<div class="category-list"><div><div class="content-category">';
$o .= '<h2>Лента новостей</h2>';
$o .= '<table class="category table table-striped table-bordered table-hover">';
$o .= '<caption class="hide">Список материалов в категории Лента новостей</caption>';
$o .= '<thead><tr><th scope="col" id="categorylist_header_title">Заголовок</th></tr></thead><tbody>';
$i = 0;
foreach ($items as $it) {
    $cls = 'cat-list-row' . ($i % 2);
    $uri = $it->get('uri');
    if ($uri === null || $uri === '') { $uri = 'blog/' . $it->get('alias'); }
    $txt = $it->get('introtext');
    if ($txt === null || trim($txt) === '') { $txt = $it->get('pagetitle'); }
    $o .= '<tr class="' . $cls . '"><td headers="categorylist_header_title" class="list-title">';
    $o .= '<a href="/' . ltrim($uri, '/') . '">' . $esc($txt) . '</a>';
    $o .= '</td></tr>';
    $i++;
}
$o .= '</tbody></table>';
$o .= '</div></div></div>';
return $o;
