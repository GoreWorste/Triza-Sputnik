<?php
/**
 * jobDetail — renders a single vacancy detail from the CURRENT resource's TVs.
 * Used by the "vacancy" template.
 */
$r = $modx->resource;
if (!$r) return '';
$esc = function ($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); };

$id       = (int)$r->get('id');
$title    = $r->get('pagetitle');
$city     = (string)$r->getTVValue('vac_city');
$contract = (string)$r->getTVValue('vac_contract');
$start    = (string)$r->getTVValue('vac_start');
$salary   = (string)$r->getTVValue('vac_salary');
$tasks    = (string)$r->getTVValue('vac_tasks');
$profile  = (string)$r->getTVValue('vac_profile');
$persp    = (string)$r->getTVValue('vac_perspective');
$contacts = (string)$r->getTVValue('vac_contacts');

$labels = array('0'=>'Полный рабочий день','1'=>'Временный сотрудник','2'=>'Сменный график','3'=>'Вахта');
$cl = isset($labels[$contract]) ? $labels[$contract] : $contract;
if ($start === '') $start = 'Ближайшее время';

$o  = '<div id="cwhire_joblication">' . "\n";
$o .= '    <a href="/vacancy"><b>К списку вакансий</b></a><br><br>' . "\n";
$o .= '    <div class="item_fields">' . "\n";
$o .= '    <div class="item_header" id="item_header_' . $id . '">' . "\n";
$o .= '      <div class="itemlist_title"><h3 class="jobtitle">' . $esc($title) . '</h3></div>' . "\n";
$o .= '      <div class="item_header_textstr">Город: <span itemtype="http://schema.org/Place" itemscope="" itemprop="jobLocation">' . $esc($city) . '</span></div>' . "\n";
$o .= '      <div class="item_header_textstr">' . $esc($cl) . '</div>' . "\n";
$o .= '      <div class="item_header_textstr">Дата начала: ' . $esc($start) . '</div>' . "\n";
$o .= '      <div class="item_header_textstr" style="clear: right;"></div>' . "\n";
$o .= '    </div>' . "\n";
if (trim($salary) !== '')
    $o .= '    <div class="jobdescription"><b>Заработная плата</b><br /> ' . $salary . '</div>' . "\n";
if (trim($tasks) !== '')
    $o .= '    <div class="jobtasks"><b>Требования к кандидату</b><br /> ' . $tasks . '</div>' . "\n";
if (trim($profile) !== '')
    $o .= '    <div class="jobprofile"><b>Характер выполняемой работы</b><br /> ' . $profile . '</div>' . "\n";
if (trim($persp) !== '')
    $o .= '    <div class="jobperspective"><b>Условия работы:</b><br /> ' . $persp . '</div>' . "\n";
$o .= '    <div class="job_contactinfo">' . trim($contacts) . '</div>' . "\n";
$o .= '    </div>' . "\n</div>";
return $o;
