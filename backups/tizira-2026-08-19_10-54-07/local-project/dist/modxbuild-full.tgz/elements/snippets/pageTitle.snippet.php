<?php
/**
 * pageTitle — renders the sp-page-title section:
 *   - slider (home)   : fotorama slider chunk
 *   - breadcrumb (def): Главная / <pagetitle>
 *   - none            : empty
 */
$mode = 'breadcrumb';
$title = '';
if ($modx->resource) {
    $tv = $modx->resource->getTVValue('title_mode');
    if ($tv !== null && $tv !== '') $mode = $tv;
    $title = $modx->resource->get('pagetitle');
    $intro = $modx->resource->get('introtext');
    if ($intro !== null && trim($intro) !== '' && $modx->resource->get('parent')) {
        // news items store full title in introtext
        $title = $intro;
    }
}
if ($mode === 'none') return '';
if ($mode === 'slider') {
    return $modx->getChunk('slider');
}
// breadcrumb
$t = htmlspecialchars($title, ENT_QUOTES, 'UTF-8');
$out  = '<section id="sp-page-title"><div class="row"><div id="sp-title" class="col-sm-12 col-md-12">'
      . '<div class="sp-column "><div class="sp-module "><div class="sp-module-content">' . "\n";
$out .= '<ol class="breadcrumb">' . "\n";
$out .= "\t" . '<li><i class="fa fa-home"></i></li><li><a href="/" class="pathway">Главная</a></li>'
      . '<li class="active">' . $t . '</li></ol>' . "\n";
$out .= '</div></div></div></div></div></section>';
return $out;
